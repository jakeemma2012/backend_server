package com.ProjectMovieJakeAndDung.MovieBackendSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieBackendSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieBackendSpringBootApplication.class, args);
	}

}
